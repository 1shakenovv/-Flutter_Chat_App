# Flash Chat ⚡️

<img src="https://github.com/D4vr4n/Flutter_Chat_App/blob/main/images/app.gif" width="360" height="800">


